#library(mvtnorm)
#library(Matrix)


##########################################################################################
####  Functions used to calculated restricted ROC, AUC, and pAUC estimators     #################
##########################################################################################

###################################################
### The choice of weight function ####
### Type 1:  based on the intraclass correlation function (Rosner et a., 2006)
#' ICC_fun
#'
#' @export

ICC_fun <- function(dat.list, mi)
{
  m <- length(mi)
  dat.len <- length(unlist(dat.list))
  if(dat.len==m)
  {
    Adjrho.est <- 1
  }
  else
  {
    overallMean <- mean(unlist(dat.list))
    ### use the intraclass correlation to estimate the correlation
    varIn.vec <- rep(NA, m)  ## the vector of within correlation
    bar.vec <- rep(NA, m)
    for(i in 1:m)
    {
      tempdat <- dat.list[[i]]
      bar.vec[i] <- mean(tempdat)
      varIn.vec[i] <- sum((tempdat-mean(tempdat))^2)
    }
    sigmaIn <- sum(varIn.vec)/(dat.len-m)
    g0 <- (sum(mi)-sum(mi^2)/sum(mi))/(m-1)
    sigmaBet <- (sum(mi*(bar.vec-overallMean)^2)/(m-1)-sigmaIn)/g0
    sigmaBet <- max(sigmaBet, 0)
    rho.est <- max(sigmaBet/(sigmaBet+sigmaIn), 0)
    Adjrho.est <- rho.est*(1+(1-rho.est^2)/(m-2.5))
  }
  return(Adjrho.est)
}

###### Type 2: based on the estimate efficient number of a matrix (Nyholt, 2004)
##ENM_fun

###################################################
##### Weighted distribution function estimator
#' weightCDF
#'
#' @export
weightCDF <- function(dat, subID, u, type)
{
  uniID <- unique(subID)
  m <- length(uniID)
  mi <- rep(NA, m)
  ## store the data by a list
  dat.list <- vector("list", m)
  for(i in 1:m)
  {
    dat.list[[i]] <- dat[subID==uniID[i]]
    mi[i] <- sum(subID==uniID[i])
  }
  ##### estimate the weight function for each subject
  ##type 0: equal weight for each subject
  ## type 1 and 2: weight based on ICC but with different forms
  ## type 3: weight based on efficient number of a matrix
  ## type 4: equal weight for each observation (conventional empirical estimator)
  if(type==0)
  {
    eta_i <- 1/mi
  }
  else if(type==1)
  {
    rhoEst <- ICC_fun(dat.list=dat.list, mi=mi)
    eta_i <- mi^(-rhoEst)
  }
  else if(type==2)
  {
    rhoEst <- ICC_fun(dat.list=dat.list, mi=mi)
    eta_i <- 1/(1+(mi-1)*rhoEst)
  }
  else if(type==3)
  {
    enmEst <- ENM_fun(dat.list=dat.list, mi=mi)
    eta_i <- mi/enmEst
  }
  else if(type==4)
  {
    eta_i <- rep(1,m)
  }
  wi <- eta_i/(sum(eta_i*mi)/m)
  IndVec <- lapply(dat.list, function(zz) sum(zz<=u))
  CDF_res <- sum(wi*unlist(IndVec))/m
  return(CDF_res)
}


### define the cumsum function for Q (based on pooled observations of X and Y)
#' cumFu
#'
#' @export
cumFun <- function(x, XsubID, y, YsubID, type, eta)
{
  x.size <- length(x)
  y.size <- length(y)
  z <- sort(c(x, y), decreasing=F)
  z.size <- x.size+y.size
  combineCDF <- rep(NA, z.size)
  for(i in 1:z.size)
  {
    temp1 <- weightCDF(dat=x, subID=XsubID, u=z[i], type=type)
    temp2 <- weightCDF(dat=y, subID=YsubID, u=z[i], type=type)
    combineCDF[i] <- eta*temp1 + (1-eta)*temp2
  }
  return(combineCDF)
}


########################################################################################
### the restricted CDF estimators of the ROC value
#' weightCDF_ICC
#'
#' @export
weightCDF_ICC <- function(dat, subID, u, ICCest)
{
  uniID <- unique(subID)
  m <- length(uniID)
  mi <- rep(NA, m)
  ## store the data by a list
  dat.list <- vector("list", m)
  for(i in 1:m)
  {
    dat.list[[i]] <- dat[subID==uniID[i]]
    mi[i] <- sum(subID==uniID[i])
  }
  ##### estimate the weight function for each subject
  eta_i <- 1/(1+(mi-1)*ICCest)
  wi <- eta_i/(sum(eta_i*mi)/m)
  IndVec <- lapply(dat.list, function(zz) sum(zz<=u))
  CDF_res <- sum(wi*unlist(IndVec))/m
  return(CDF_res)
}

#' cumFun_ICC
#'
#' @export
cumFun_ICC <- function(x, XsubID, y, YsubID, x_ICC, y_ICC, eta)
{
  x.size <- length(x)
  y.size <- length(y)
  z <- sort(c(x, y), decreasing=F)
  z.size <- x.size+y.size
  combineCDF <- rep(NA, z.size)
  for(i in 1:z.size)
  {
    temp1 <- weightCDF_ICC(dat=x, subID=XsubID, u=z[i], ICCest=x_ICC)
    temp2 <- weightCDF_ICC(dat=y, subID=YsubID, u=z[i], ICCest=y_ICC)
    combineCDF[i] <- eta*temp1 + (1-eta)*temp2
  }
  return(combineCDF)
}


#' rocR
#'
#' @export
rocR <- function(x, XsubID, y, YsubID, x_ICC, y_ICC, eta, u)
{
  orderLOC <- order(y, decreasing=F)
  y <- y[orderLOC]
  YsubID <- YsubID[orderLOC]
  empDis <- rep(NA, length(y))
  for(i in 1:length(y))
  {
    empDis[i] <- weightCDF_ICC(dat=y, subID=YsubID, u=y[i], ICCest=y_ICC)
  }
  invG1 <- y[min(which(empDis>=1-u))]
  poolCDF <- cumFun_ICC(x=x, XsubID=XsubID, y=y, YsubID=YsubID, x_ICC=x_ICC, y_ICC=y_ICC, eta=eta)
  loc <- min(which(poolCDF>=1-u))
  invG2 <- sort(c(x, y), decreasing=F)[loc]
  res.invG <- min(invG1, invG2)
  temp1 <- weightCDF_ICC(dat=x, subID=XsubID, u=res.invG, ICCest=x_ICC)
  temp2 <- weightCDF_ICC(dat=y, subID=YsubID, u=res.invG, ICCest=y_ICC)
  Q.invG <- eta*temp1+(1-eta)*temp2
  res.roc <- 1-min(temp1, Q.invG)
  return(res.roc)
}

##### ordered estimator of AUC
#' SUM_AUCorder
#'
#' @export
SUM_AUCorder <- function(x, XsubID, y, YsubID, x_ICC, y_ICC, eta)
{
  x.size <- length(x)
  y.size <- length(y)
  z <- sort(c(x,y), decreasing=F)
  z.new <- c(-Inf, z)
  tempVal <- rep(NA, x.size+y.size)
  for(j in 1:(x.size+y.size))
  {
    temp0CDFx <- weightCDF_ICC(dat=x, subID=XsubID, u=z.new[j], ICCest=x_ICC)
    temp0CDFy <- weightCDF_ICC(dat=y, subID=YsubID, u=z.new[j], ICCest=y_ICC)
    temp1CDFx <- weightCDF_ICC(dat=x, subID=XsubID, u=z.new[j+1], ICCest=x_ICC)
    temp1CDFy <- weightCDF_ICC(dat=y, subID=YsubID, u=z.new[j+1], ICCest=y_ICC)
    ak <- min(temp1CDFx, eta*temp0CDFx+(1-eta)*temp0CDFy)
    bk <- ((1-eta)*temp1CDFy+eta*max(temp1CDFx, temp1CDFy))-((1-eta)*temp0CDFy+eta*max(temp0CDFx, temp0CDFy))
    tempVal[j] <- ak*bk
  }
  auc <- 1-sum(tempVal)
  return(auc)
}

##### ordered estimator of pAUC

#' SUM_pAUCorder
#'
#' @export
SUM_pAUCorder <- function(x, XsubID, y, YsubID, x_ICC, y_ICC, eta, tau)
{
  x.size <- length(x)
  y.size <- length(y)
  z <- sort(c(x,y), decreasing=F)
  GtildeCDF <- rep(NA, (x.size+y.size))
  for(i in 1:(x.size+y.size))
  {
    temp1 <- weightCDF_ICC(dat=y, subID=YsubID, u=z[i], ICCest=y_ICC)
    temp2 <- weightCDF_ICC(dat=x, subID=XsubID, u=z[i], ICCest=x_ICC)
    GtildeCDF[i] <- (1-eta)*temp1 + eta*max(temp2, temp1)
  }
  minK <- min(which(1-tau <= GtildeCDF))
  if(minK>1 & minK < x.size+y.size)
  {
    F0 <- weightCDF_ICC(dat=x, subID=XsubID, u=z[minK-1], ICCest=x_ICC)
    G0 <- weightCDF_ICC(dat=y, subID=YsubID, u=z[minK-1], ICCest=y_ICC)
    F1 <- weightCDF_ICC(dat=x, subID=XsubID, u=z[minK], ICCest=x_ICC)
    G1 <- weightCDF_ICC(dat=y, subID=YsubID, u=z[minK], ICCest=y_ICC)
    G_minK <- (1-eta)*G1+eta*max(F1, G1)
    temp1 <- min(F1, eta*F0+(1-eta)*G0)*(G_minK-1+tau)
    temp2 <- rep(NA, x.size+y.size-minK)
    for(j in minK:(x.size+y.size-1))
    {
      F2 <- weightCDF_ICC(dat=x, subID=XsubID, u=z[j], ICCest=x_ICC)
      G2 <- weightCDF_ICC(dat=y, subID=YsubID, u=z[j], ICCest=y_ICC)
      F3 <- weightCDF_ICC(dat=x, subID=XsubID, u=z[j+1], ICCest=x_ICC)
      G3 <- weightCDF_ICC(dat=y, subID=YsubID, u=z[j+1], ICCest=y_ICC)
      ak <- 1/(1-eta)*min(F3, eta*F2+(1-eta)*G2)
      bk <- ((1-eta)/eta*G3+max(F3, G3))-((1-eta)/eta*G2+max(F2, G2))
      temp2[j-minK+1] <- ak*bk
    }
    pauc <- tau-temp1-eta*(1-eta)*sum(temp2)
  }
  else if(minK==1)
  {
    temp3 <- rep(NA, x.size+y.size-1)
    for(j in 2:(x.size+y.size))
    {
      F2 <- weightCDF_ICC(dat=x, subID=XsubID, u=z[j-1], ICCest=x_ICC)
      G2 <- weightCDF_ICC(dat=y, subID=YsubID, u=z[j-1], ICCest=y_ICC)
      F3 <- weightCDF_ICC(dat=x, subID=XsubID, u=z[j], ICCest=x_ICC)
      G3 <- weightCDF_ICC(dat=y, subID=YsubID, u=z[j], ICCest=y_ICC)
      ak <- 1/(1-eta)*min(F3, eta*F2+(1-eta)*G2)
      bk <- ((1-eta)/eta*G3+max(F3, G3))-((1-eta)/eta*G2+max(F2, G2))
      temp3[j-1] <- eta*(1-eta)*ak*bk
    }
    pauc <- tau-sum(temp3)
  }
  else
  {
    F0 <- weightCDF_ICC(dat=x, subID=XsubID, u=z[minK-1], ICCest=x_ICC)
    G0 <- weightCDF_ICC(dat=y, subID=YsubID, u=z[minK-1], ICCest=y_ICC)
    F1 <- weightCDF_ICC(dat=x, subID=XsubID, u=z[minK], ICCest=x_ICC)
    G1 <- weightCDF_ICC(dat=y, subID=YsubID, u=z[minK], ICCest=y_ICC)
    G_minK <- (1-eta)*G1+eta*max(F1, G1)
    temp4 <- (min(F1, eta*F0+(1-eta)*G0))*(G_minK-1+tau)
    pauc <- tau-temp4
  }
  return(pauc)
}

###############################################################################
############# Functions for Monte Carlo resampling approach  ##############
##############################################################################
### x and y are both lists


##### Weighted distribution function estimator
#' weightCDF_Monte
#'
#' @export
weightCDF_Monte <- function(dat, u, type)
{
  m <- length(dat)
  mi <- unlist(lapply(dat, length))
  M <- sum(mi)
  ##### estimate the weight function for each subject
  ##type 0: equal weight for each subject
  ## type 1 and 2: weight based on ICC but with different forms
  ## type 3: weight based on efficient number of a matrix
  ## type 4: equal weight for each observation (conventional empirical estimator)
  if(type==0)
  {
    w0_i <- 1/mi
  }
  else if(type==1)
  {
    rhoEst <- ICC_fun(dat.list=dat, mi=mi)
    w0_i <- mi^(-rhoEst)
  }
  else if(type==2)
  {
    rhoEst <- ICC_fun(dat.list=dat, mi=mi)
    w0_i <- 1/(1+(mi-1)*rhoEst)
  }
  else if(type==3)
  {
    enmEst <- ENM_fun(dat.list=dat, mi=mi)
    w0_i <- mi/enmEst
  }
  else if(type==4)
  {
    w0_i <- rep(1,m)
  }
  wi <- M*w0_i/(sum(w0_i*mi))
  IndVec <- lapply(dat, function(zz) sum(zz<=u))
  CDF_res <- sum(wi*unlist(IndVec))/M
  return(CDF_res)
}

#' Wwe_star
#'
#' @export
Wwe_star <- function(dat, z, type, tt)
{
  m <- length(dat)
  mi <- unlist(lapply(dat, length))
  cdf <- weightCDF_Monte(dat=dat, u=tt, type=type)
  M <- sum(mi)
  #################### calculate the weight
  if(type==0)
  {
    w0_i <- 1/mi
  }
  else if(type==1)
  {
    rhoEst <- ICC_fun(dat.list=dat, mi=mi)
    w0_i <- mi^(-rhoEst)
  }
  else if(type==2)
  {
    rhoEst <- ICC_fun(dat.list=dat, mi=mi)
    w0_i <- 1/(1+(mi-1)*rhoEst)
  }
  else if(type==3)
  {
    enmEst <- ENM_fun(dat.list=dat, mi=mi)
    w0_i <- mi/enmEst
  }
  else if(type==4)
  {
    w0_i <- rep(1,m)
  }
  wi <- M*w0_i/(sum(w0_i*mi))
  subCount <- rep(NA, m)
  for(i in 1:m)  subCount[i] <- wi[i]*(sum(dat[[i]]<=tt)-mi[i]*cdf)
  res <- sqrt(m)*(sum(z*subCount))/sum(mi)
  return(res)
}

########################################################################################
#' cdf_order
#'
#' @export
cdf_order <- function(x, y, type, eta, tt)
{
  m <- length(x)
  Ft <- weightCDF_Monte(dat=x, u=tt, type=type)
  Gt <- weightCDF_Monte(dat=y, u=tt, type=type)
  Qt <- eta*Ft + (1-eta)*Gt
  Ftilde <- min(Ft, Qt)
  Gtilde <- max(Gt, Qt)
  return(list(Ftilde=Ftilde, Gtilde=Gtilde))
}

#' invG_order
#'
#' @export
invG_order <- function(x, y, type, eta, u)
{
  m <- length(x)
  xlong <- unlist(x)
  ylong <- unlist(y)
  xy <- sort(c(xlong, ylong), decreasing=F)
  MN <- length(xy)

  empDis <- apply(matrix(xy, ncol=1), 1, function(para) return(cdf_order(x=x, y=y, type=type, eta=eta, tt=para)$Gtilde))
  if(u<empDis[1])
  {
    res <- -Inf
  }
  else if(u>max(empDis))
  {
    res <- xy[MN]
  }
  else  res <- xy[min(which(empDis>=u))]
  return(res)
}

#' WFGorder_star
#'
#' @export
WFGorder_star <- function(x, y, z, type, eta, tt)
{
  WFstar <- Wwe_star(dat=x, z=z, type=type, tt=tt)
  WGstar <- Wwe_star(dat=y, z=z, type=type, tt=tt)
  WQstar <- eta*WFstar+(1-eta)*WGstar
  resF <- min(WFstar, WQstar)
  resG <- max(WGstar, WQstar)
  return(list(WF=resF, WG=resG))
}

#' rocR_star
#'
#' @export
rocR_star <- function(x, y, z, type, eta, spe)
{
  m <- length(x)
  invG1 <- invG_order(x=x, y=y, type=type, eta=eta, u=1-spe)
  temp1 <- WFGorder_star(x=x, y=y, z=z, type=type, eta=eta, tt=invG1)$WG
  temp2 <- 1-spe+temp1/sqrt(m)
  xiVal <- invG_order(x=x, y=y, type=type, eta=eta, u=temp2)
  temp3 <- cdf_order(x=x, y=y, type=type, eta=eta, tt=xiVal)$Ftilde
  temp4 <- WFGorder_star(x=x, y=y, z=z, type=type, eta=eta, tt=xiVal)$WF
  zetaVal <- temp3-temp4/sqrt(m)
  rocVal <- 1-zetaVal
  return(rocVal)
}

#' XI_order
#'
#' @export
XI_order<- function(x, y, z, type, eta)
{
  m <- length(x)
  xlong <- unlist(x)
  ylong <- unlist(y)
  xysort <- sort(c(xlong, ylong), decreasing=F)
  MN <- length(xysort)
  uVec <- rep(NA, MN)
  for(i in 1:MN)  uVec[i] <- cdf_order(x=x, y=y, type=type, eta=eta, tt=xysort[i])$Gtilde
  uVec <- c(0, uVec)
  xiVal <- rep(NA, MN+1)
  for(i in 1:(MN+1))
  {
    invG1 <- invG_order(x=x, y=y, type=type, eta=eta, u=uVec[i])
    temp1 <- WFGorder_star(x=x, y=y, z=z, type=type, eta=eta, tt=invG1)$WG
    temp2 <- uVec[i]+temp1/sqrt(m)
    xiVal[i] <- invG_order(x=x, y=y, type=type, eta=eta, u=temp2)
  }
  res <- list(arg1=uVec, arg2=xiVal)
  return(res)
}

#' AUCorder_star
#'
#' @export
AUCorder_star <- function(x, y, z, type, eta)
{
  m <- length(x)
  tempXI <- XI_order(x=x, y=y, z=z, type=type, eta=eta)
  invXI <- tempXI$arg1
  XIval <- tempXI$arg2
  len <- length(invXI)-1
  tempVal <- rep(NA, len)
  for(i in 1:len)
  {
    invXi0 <- invXI[i]
    invXi1 <- invXI[i+1]
    temp3 <- cdf_order(x=x, y=y, type=type, eta=eta, tt=XIval[i+1])$Ftilde
    temp4 <- WFGorder_star(x=x, y=y, z=z, type=type, eta=eta, tt=XIval[i+1])$WF
    zeta1 <- temp3-temp4/sqrt(m)
    tempVal[i] <- zeta1*(invXi1-invXi0)
  }
  auc <- 1-sum(tempVal)
  return(auc)
}
