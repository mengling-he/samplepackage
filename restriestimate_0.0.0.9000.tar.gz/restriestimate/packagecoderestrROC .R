dir()

##edit description
file.edit('description')



devtools::document()

##documentation pending


###MainFuns:  AUCorder_star;   cdf_order; cumFun;  cumFun_ICC;
       ###### ENM_fun;  ICC_fun;  invG_order;  rocR;  rocR_star;
       ###### SUM_AUCorder;  SUM_pAUCorder;
       ###### weightCDF_Monte; Wwe_star;  weightCDF;weightCDF_ICC;  WFGorder_star;
       ###### XI_order;

subData<-read.table("./data/Application_Dataset1.txt",header=F,
                   colClasses=c("numeric", "numeric", rep("character",5)), stringsAsFactors=F)

mi<-read.table ("./data/Application_Dataset2_female.txt")


##install
devtools::install ()

##distribute package
devtools:install_github("yourusername/packagename")
